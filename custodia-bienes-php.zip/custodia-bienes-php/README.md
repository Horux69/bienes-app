# Custodia de Bienes — PHP + Supabase

## Puesta en marcha

1. **Base de datos**: en el SQL Editor de tu proyecto Supabase, corre `schema.sql`.
2. **Storage**: crea un bucket llamado `bienes-fotos` (Storage → New bucket).
3. **Credenciales**: copia `config.php` y completa (o mejor, define como variables de entorno):
   - `SUPABASE_DB_HOST`, `SUPABASE_DB_PASSWORD` — en Supabase: Project Settings → Database.
   - `SUPABASE_URL` — Project Settings → API.
   - `SUPABASE_SERVICE_KEY` — Project Settings → API → `service_role` (secreta, solo backend).
4. Sube la carpeta a tu hosting con PHP 8.2 y extensión `pdo_pgsql` habilitada.
5. Abre `index.php` desde el celular en el juzgado.

## Estructura

- `index.php` — formulario (Bootstrap) y vista de historial
- `assets/app.js` — captura de foto, artículos/subitems dinámicos, llamadas AJAX
- `api/guardar_acta.php` — guarda acta + artículos + subitems, sube fotos a Storage
- `api/listar_actas.php` — devuelve el historial para la pestaña Historial
- `db.php` / `storage.php` — helpers de conexión
- `schema.sql` — tablas `actas`, `articulos`, `subitems`

## Notas

- Las fotos se comprimen en el navegador (máx. 900px, JPEG 70%) antes de enviarse, para que la subida sea rápida en 4G desde el juzgado.
- La `service_role` key de Supabase nunca debe usarse en el frontend — por eso la subida a Storage pasa por `storage.php` en el backend.
- Si tu hosting no tiene `pdo_pgsql`, la alternativa es usar la API REST de Supabase (PostgREST) en vez de conexión directa; se puede adaptar `db.php` a llamadas `curl` si hace falta.

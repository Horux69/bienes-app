<?php
header('Content-Type: application/json; charset=utf-8');
require __DIR__ . '/../db.php';
require __DIR__ . '/../storage.php';

$input = json_decode(file_get_contents('php://input'), true);

if (
    !$input
    || empty($input['ciudad'])
    || empty($input['juzgado'])
    || empty($input['responsable'])
    || empty($input['articulos'])
) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Faltan campos obligatorios (ciudad, juzgado, responsable o artículos).']);
    exit;
}

$pdo = getPDO();

try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare('insert into actas (ciudad, juzgado, responsable) values (?, ?, ?) returning id');
    $stmt->execute([$input['ciudad'], $input['juzgado'], $input['responsable']]);
    $actaId = $stmt->fetchColumn();

    foreach ($input['articulos'] as $articulo) {
        if (empty($articulo['nombre'])) continue;

        $fotoUrl = null;
        if (!empty($articulo['foto'])) {
            $nombreArchivo = uniqid('bien_', true) . '.jpg';
            $fotoUrl = subirFotoSupabase($articulo['foto'], $nombreArchivo);
        }

        $stmt = $pdo->prepare('insert into articulos (acta_id, nombre, foto_url) values (?, ?, ?) returning id');
        $stmt->execute([$actaId, $articulo['nombre'], $fotoUrl]);
        $articuloId = $stmt->fetchColumn();

        if (!empty($articulo['subitems']) && is_array($articulo['subitems'])) {
            $stmtSub = $pdo->prepare('insert into subitems (articulo_id, nombre) values (?, ?)');
            foreach ($articulo['subitems'] as $sub) {
                $sub = trim((string) $sub);
                if ($sub === '') continue;
                $stmtSub->execute([$articuloId, $sub]);
            }
        }
    }

    $pdo->commit();
    echo json_encode(['ok' => true, 'acta_id' => $actaId]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}

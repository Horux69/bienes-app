<?php
header('Content-Type: application/json; charset=utf-8');
require __DIR__ . '/../db.php';

try {
    $pdo = getPDO();
    $actas = $pdo->query('select * from actas order by fecha desc limit 100')->fetchAll();

    $stmtArt = $pdo->prepare('select * from articulos where acta_id = ? order by created_at');
    $stmtSub = $pdo->prepare('select nombre from subitems where articulo_id = ? order by nombre');

    foreach ($actas as &$acta) {
        $stmtArt->execute([$acta['id']]);
        $articulos = $stmtArt->fetchAll();

        foreach ($articulos as &$art) {
            $stmtSub->execute([$art['id']]);
            $art['subitems'] = array_column($stmtSub->fetchAll(), 'nombre');
        }
        unset($art);

        $acta['articulos'] = $articulos;
    }
    unset($acta);

    echo json_encode(['ok' => true, 'actas' => $actas]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}

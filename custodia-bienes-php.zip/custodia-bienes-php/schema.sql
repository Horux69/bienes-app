-- Ejecutar en el SQL editor de Supabase

create extension if not exists "pgcrypto";

create table if not exists actas (
  id uuid primary key default gen_random_uuid(),
  ciudad text not null,
  juzgado text not null,
  responsable text not null,
  fecha timestamptz not null default now()
);

create table if not exists articulos (
  id uuid primary key default gen_random_uuid(),
  acta_id uuid not null references actas(id) on delete cascade,
  nombre text not null,
  foto_url text,
  created_at timestamptz not null default now()
);

create table if not exists subitems (
  id uuid primary key default gen_random_uuid(),
  articulo_id uuid not null references articulos(id) on delete cascade,
  nombre text not null
);

create index if not exists idx_articulos_acta on articulos(acta_id);
create index if not exists idx_subitems_articulo on subitems(articulo_id);

-- En Supabase Storage, crea un bucket llamado "bienes-fotos" (puede ser privado,
-- el backend sube y lee usando la service role key).

<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Custodia de Bienes</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
  body { background: #eef1ee; padding-bottom: 40px; }
  .container-app { max-width: 520px; margin: 0 auto; padding-top: 20px; }
  .eyebrow { font-size: 12px; letter-spacing: .02em; color: #2b6e5e; font-weight: 600; }
  h1 { font-size: 22px; font-weight: 700; }
  .card-art { border: 1px solid #dee2e6; border-radius: 10px; padding: 14px; margin-bottom: 14px; background: #fff; }
  .photo-box { border: 1.5px dashed #ced4da; border-radius: 10px; text-align: center; padding: 18px; cursor: pointer; background: #fbfcfb; margin-bottom: 10px; }
  .photo-box img { max-width: 100%; max-height: 220px; border-radius: 8px; }
  .subitem-chip { display: inline-flex; align-items: center; gap: 6px; background: #f3e4d6; color: #b65c1e; font-weight: 600; font-size: 13px; padding: 4px 10px; border-radius: 20px; margin: 3px 4px 0 0; }
  .subitem-chip button { border: none; background: none; color: #b65c1e; font-weight: 700; line-height: 1; padding: 0; }
  .btn-quitar-articulo { color: #b5432e; }
  .item-historial img { width: 56px; height: 56px; object-fit: cover; border-radius: 8px; background: #dee2e6; }
  .code-badge { font-family: monospace; font-size: 12px; color: #6c757d; }
</style>
</head>
<body>
<div class="container-app">
  <div class="eyebrow">Cadena de custodia</div>
  <h1 class="mb-3">Custodia de Bienes</h1>

  <ul class="nav nav-pills mb-3" id="tabSwitch">
    <li class="nav-item"><button class="nav-link active" data-tab="registrar">Registrar</button></li>
    <li class="nav-item"><button class="nav-link" data-tab="historial">Historial</button></li>
  </ul>

  <!-- REGISTRAR -->
  <div id="panelRegistrar">
    <form id="formActa">
      <div class="mb-2">
        <label class="form-label small fw-semibold">Ciudad</label>
        <input type="text" class="form-control" name="ciudad" required>
      </div>
      <div class="mb-2">
        <label class="form-label small fw-semibold">Juzgado</label>
        <input type="text" class="form-control" name="juzgado" required>
      </div>
      <div class="mb-3">
        <label class="form-label small fw-semibold">Quién hace el inventario</label>
        <input type="text" class="form-control" name="responsable" required>
      </div>

      <div id="listaArticulos"></div>

      <button type="button" id="btnAgregarArticulo" class="btn btn-outline-secondary btn-sm w-100 mb-3">
        + Agregar artículo
      </button>

      <button type="submit" class="btn btn-success w-100" id="btnGuardar">Guardar acta</button>
      <div id="msgActa" class="text-center small mt-2"></div>
    </form>
  </div>

  <!-- HISTORIAL -->
  <div id="panelHistorial" class="d-none">
    <div id="listaHistorial"></div>
  </div>
</div>

<!-- plantilla de un artículo (oculta) -->
<template id="tplArticulo">
  <div class="card-art" data-articulo>
    <div class="d-flex justify-content-between align-items-center mb-2">
      <span class="small fw-semibold text-secondary">Artículo</span>
      <button type="button" class="btn btn-sm btn-quitar-articulo" data-quitar-articulo>Quitar</button>
    </div>

    <div class="photo-box" data-photo-box>
      <div data-photo-placeholder>📷 <span class="small d-block text-secondary mt-1">Tomar foto</span></div>
      <img data-photo-preview class="d-none" alt="">
    </div>
    <input type="file" accept="image/*" capture="environment" class="d-none" data-photo-input>

    <div class="mb-2">
      <input type="text" class="form-control form-control-sm" placeholder="Nombre del artículo (ej. Computadora)" data-nombre-articulo required>
    </div>

    <div class="mb-2">
      <div data-subitems-chips class="mb-1"></div>
      <input type="text" class="form-control form-control-sm" placeholder="Agregar subitem (ej. Teclado) y Enter" data-subitem-input>
    </div>
  </div>
</template>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/app.js"></script>
</body>
</html>

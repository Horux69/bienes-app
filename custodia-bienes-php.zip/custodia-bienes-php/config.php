<?php
// Reemplaza estos valores con los de tu proyecto Supabase
// (Configuración > Database, y Configuración > API para las keys)
// Mejor aún: ponlos como variables de entorno en tu servidor, no aquí.

return [
    'db' => [
        'host' => getenv('SUPABASE_DB_HOST') ?: 'db.xxxxxxxxxxxx.supabase.co',
        'port' => getenv('SUPABASE_DB_PORT') ?: '5432',
        'dbname' => getenv('SUPABASE_DB_NAME') ?: 'postgres',
        'user' => getenv('SUPABASE_DB_USER') ?: 'postgres',
        'password' => getenv('SUPABASE_DB_PASSWORD') ?: 'TU_PASSWORD',
    ],
    'storage' => [
        'url' => getenv('SUPABASE_URL') ? getenv('SUPABASE_URL') . '/storage/v1' : 'https://xxxxxxxxxxxx.supabase.co/storage/v1',
        'bucket' => 'bienes-fotos',
        // Service Role key: SOLO en el backend. Nunca la pongas en JavaScript.
        'service_key' => getenv('SUPABASE_SERVICE_KEY') ?: 'TU_SERVICE_ROLE_KEY',
    ],
];

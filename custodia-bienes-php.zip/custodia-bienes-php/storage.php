<?php

/**
 * Sube una foto (dataURL base64) a Supabase Storage y devuelve la URL pública.
 */
function subirFotoSupabase(string $base64Data, string $nombreArchivo): string
{
    $cfg = require __DIR__ . '/config.php';
    $s = $cfg['storage'];

    if (strpos($base64Data, ',') !== false) {
        [, $base64Data] = explode(',', $base64Data, 2);
    }
    $binario = base64_decode($base64Data);
    if ($binario === false) {
        throw new RuntimeException('Foto inválida.');
    }

    $ruta = date('Y/m/') . $nombreArchivo;
    $url = $s['url'] . '/object/' . $s['bucket'] . '/' . $ruta;

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => $binario,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . $s['service_key'],
            'Content-Type: image/jpeg',
            'x-upsert: true',
        ],
        CURLOPT_RETURNTRANSFER => true,
    ]);
    $respuesta = curl_exec($ch);
    $codigo = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $errorCurl = curl_error($ch);
    curl_close($ch);

    if ($errorCurl) {
        throw new RuntimeException('Error de red subiendo foto: ' . $errorCurl);
    }
    if ($codigo >= 300) {
        throw new RuntimeException('Supabase Storage respondió ' . $codigo . ': ' . $respuesta);
    }

    return $s['url'] . '/object/public/' . $s['bucket'] . '/' . $ruta;
}

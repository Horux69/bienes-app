document.addEventListener('DOMContentLoaded', () => {
  const tabButtons = document.querySelectorAll('#tabSwitch button');
  const panelRegistrar = document.getElementById('panelRegistrar');
  const panelHistorial = document.getElementById('panelHistorial');
  const listaArticulos = document.getElementById('listaArticulos');
  const tplArticulo = document.getElementById('tplArticulo');
  const btnAgregarArticulo = document.getElementById('btnAgregarArticulo');
  const formActa = document.getElementById('formActa');
  const btnGuardar = document.getElementById('btnGuardar');
  const msgActa = document.getElementById('msgActa');
  const listaHistorial = document.getElementById('listaHistorial');

  // --- Tabs ---
  tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      tabButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const tab = btn.dataset.tab;
      panelRegistrar.classList.toggle('d-none', tab !== 'registrar');
      panelHistorial.classList.toggle('d-none', tab !== 'historial');
      if (tab === 'historial') cargarHistorial();
    });
  });

  // --- Comprimir imagen a JPEG antes de enviarla ---
  function comprimirImagen(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = e => {
        const img = new Image();
        img.onload = () => {
          const maxW = 900;
          const scale = Math.min(1, maxW / img.width);
          const canvas = document.createElement('canvas');
          canvas.width = img.width * scale;
          canvas.height = img.height * scale;
          canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
          resolve(canvas.toDataURL('image/jpeg', 0.7));
        };
        img.onerror = reject;
        img.src = e.target.result;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  // --- Crear un bloque de artículo ---
  function agregarArticulo() {
    const nodo = tplArticulo.content.cloneNode(true);
    const card = nodo.querySelector('[data-articulo]');

    const photoBox = card.querySelector('[data-photo-box]');
    const photoInput = card.querySelector('[data-photo-input]');
    const photoPreview = card.querySelector('[data-photo-preview]');
    const photoPlaceholder = card.querySelector('[data-photo-placeholder]');
    const subitemInput = card.querySelector('[data-subitem-input]');
    const subitemsChips = card.querySelector('[data-subitems-chips]');
    const btnQuitar = card.querySelector('[data-quitar-articulo]');

    card.dataset.subitems = JSON.stringify([]);
    card.dataset.foto = '';

    photoBox.addEventListener('click', () => photoInput.click());
    photoInput.addEventListener('change', async () => {
      const file = photoInput.files[0];
      if (!file) return;
      const dataUrl = await comprimirImagen(file);
      card.dataset.foto = dataUrl;
      photoPreview.src = dataUrl;
      photoPreview.classList.remove('d-none');
      photoPlaceholder.classList.add('d-none');
    });

    subitemInput.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter') return;
      e.preventDefault();
      const valor = subitemInput.value.trim();
      if (!valor) return;
      const subitems = JSON.parse(card.dataset.subitems);
      subitems.push(valor);
      card.dataset.subitems = JSON.stringify(subitems);
      subitemInput.value = '';
      renderChips(subitemsChips, card);
    });

    btnQuitar.addEventListener('click', () => card.remove());

    listaArticulos.appendChild(card);
  }

  function renderChips(container, card) {
    const subitems = JSON.parse(card.dataset.subitems);
    container.innerHTML = subitems.map((s, i) =>
      `<span class="subitem-chip">${escapeHtml(s)}<button type="button" data-idx="${i}">&times;</button></span>`
    ).join('');
    container.querySelectorAll('button').forEach(btn => {
      btn.addEventListener('click', () => {
        const idx = parseInt(btn.dataset.idx, 10);
        const subitems = JSON.parse(card.dataset.subitems);
        subitems.splice(idx, 1);
        card.dataset.subitems = JSON.stringify(subitems);
        renderChips(container, card);
      });
    });
  }

  function escapeHtml(str) {
    return str.replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
  }

  btnAgregarArticulo.addEventListener('click', agregarArticulo);
  agregarArticulo(); // empezar con uno

  // --- Guardar acta vía AJAX ---
  formActa.addEventListener('submit', async (e) => {
    e.preventDefault();
    msgActa.textContent = '';
    msgActa.className = 'text-center small mt-2';

    const fd = new FormData(formActa);
    const articulosNodos = listaArticulos.querySelectorAll('[data-articulo]');

    const articulos = Array.from(articulosNodos).map(card => ({
      nombre: card.querySelector('[data-nombre-articulo]').value.trim(),
      foto: card.dataset.foto || null,
      subitems: JSON.parse(card.dataset.subitems || '[]'),
    })).filter(a => a.nombre !== '');

    if (articulos.length === 0) {
      msgActa.textContent = 'Agrega al menos un artículo con nombre.';
      msgActa.classList.add('text-danger');
      return;
    }

    const payload = {
      ciudad: fd.get('ciudad'),
      juzgado: fd.get('juzgado'),
      responsable: fd.get('responsable'),
      articulos,
    };

    btnGuardar.disabled = true;
    btnGuardar.textContent = 'Guardando…';

    try {
      const resp = await fetch('api/guardar_acta.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await resp.json();

      if (!resp.ok || !data.ok) {
        throw new Error(data.error || 'Error al guardar.');
      }

      msgActa.textContent = 'Acta guardada correctamente.';
      msgActa.classList.add('text-success');
      formActa.reset();
      listaArticulos.innerHTML = '';
      agregarArticulo();
    } catch (err) {
      msgActa.textContent = err.message;
      msgActa.classList.add('text-danger');
    } finally {
      btnGuardar.disabled = false;
      btnGuardar.textContent = 'Guardar acta';
    }
  });

  // --- Historial vía AJAX ---
  async function cargarHistorial() {
    listaHistorial.innerHTML = '<div class="text-center text-secondary small py-4">Cargando…</div>';
    try {
      const resp = await fetch('api/listar_actas.php');
      const data = await resp.json();
      if (!data.ok) throw new Error(data.error || 'Error al cargar.');

      if (data.actas.length === 0) {
        listaHistorial.innerHTML = '<div class="text-center text-secondary small py-4">Todavía no hay actas registradas.</div>';
        return;
      }

      listaHistorial.innerHTML = data.actas.map(acta => `
        <div class="card-art">
          <div class="d-flex justify-content-between">
            <strong>${escapeHtml(acta.juzgado)}</strong>
            <span class="code-badge">${new Date(acta.fecha).toLocaleString('es')}</span>
          </div>
          <div class="small text-secondary mb-2">${escapeHtml(acta.ciudad)} · ${escapeHtml(acta.responsable)}</div>
          ${acta.articulos.map(art => `
            <div class="d-flex align-items-center gap-2 mb-2">
              ${art.foto_url ? `<img src="${art.foto_url}" class="item-historial">` : ''}
              <div class="small">
                <div class="fw-semibold">${escapeHtml(art.nombre)}</div>
                <div class="text-secondary">${art.subitems.map(escapeHtml).join(', ')}</div>
              </div>
            </div>
          `).join('')}
        </div>
      `).join('');
    } catch (err) {
      listaHistorial.innerHTML = `<div class="text-center text-danger small py-4">${escapeHtml(err.message)}</div>`;
    }
  }
});
